#ifndef MINIPIR
#define MINIPIR

#include "xparameters.h"
#include "xtmrctr.h"
#include "gpio.h"
#include "sleep.h"


#define GROVE_UART 0
#define GROVE_G1 2
#define GROVE_G2 3
#define GROVE_G3 4
#define GROVE_G4 6
#define GROVE_G5 8
#define GROVE_G6 10
#define GROVE_G7 12

gpio PIR_init(int pin, gpio PIR);

int PIR_read(gpio PIR);

#endif
