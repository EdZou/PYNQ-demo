/******************************************************************************
 *  Copyright (c) 2019, Xilinx, Inc.
 *  All rights reserved.
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions are met:
 *
 *  1.  Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer.
 *
 *  2.  Redistributions in binary form must reproduce the above copyright 
 *      notice, this list of conditions and the following disclaimer in the 
 *      documentation and/or other materials provided with the distribution.
 *
 *  3.  Neither the name of the copyright holder nor the names of its 
 *      contributors may be used to endorse or promote products derived from 
 *      this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 *  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 *  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR 
 *  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 *  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 *  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 *  OR BUSINESS INTERRUPTION). HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
 *  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR 
 *  OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF 
 *  ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****************************************************************************/
/******************************************************************************
 *
 *
 * @file arduino_grove_psensor.c
 *
 * IOP code (MicroBlaze) for grove S16-L221D and HLS8L-DC3-S-C.
 * The relay and mini pir has to be connected to an arduino interface
 * via a shield socket.
 * relay is write only, and has simple one-bit GPIO interface.
 * mini pir is read only, and has simple one-bit GPIO interface.
 * Hardware version 2.2.
 * https://www.seeedstudio.com/Grove-mini-PIR-motion-sensor-p-2930.html
 * https://www.seeedstudio.com/Grove-Relay-p-769.html
 *
 * <pre>
 * MODIFICATION HISTORY:
 *
 * Ver   Who  Date     Changes
 * ----- --- ------- -----------------------------------------------
 * 1.00  zc  20/3/19  combine the function of mini PIR and relay
 *
 * </pre>
 *
 *****************************************************************************/

#include <circular_buffer.h>
#include <gpio.h>
#include <timer.h>
#include "arduino_grove_minipir.h"
#include "arduino_grove_relay.h"

// Work on 8-bit mode
#define CONFIG_IOP_SWITCH           0x1
#define READ_PIR                    0x3
#define WRITE_RELAY                 0x5


int main(void)
{
    int cmd;
    gpio PIR, relay;

    
    while(1){
        // wait and store valid command
        while((MAILBOX_CMD_ADDR & 0x01)==0);
        cmd = MAILBOX_CMD_ADDR;

        switch(cmd){
              case CONFIG_IOP_SWITCH:
                  // read new pin configuration
                  PIR = PIR_init(MAILBOX_DATA(0), PIR);
                  relay = relay_init(MAILBOX_DATA(1), relay);
                  MAILBOX_CMD_ADDR = 0x0;
                  break;

           case READ_PIR:
                  MAILBOX_DATA(0) = PIR_read(PIR);
                  MAILBOX_CMD_ADDR = 0x0;
                  break;

           case WRITE_RELAY:
                  relay_write(relay, MAILBOX_DATA(0));
                  MAILBOX_CMD_ADDR = 0x0;
                  break;

              default:
                  MAILBOX_CMD_ADDR = 0x0; // reset command
                  break;
           }
         }
   return(0);
}
