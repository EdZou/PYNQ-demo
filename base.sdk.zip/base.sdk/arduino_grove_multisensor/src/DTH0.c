#include "DTH0.h"

#define MAXTIMINGS 85

#define DHT11 11
#define DHT22 22
#define DHT21 21
#define AM2301 21

#define GROVE_UART 0
#define GROVE_G1 2
#define GROVE_G2 3
#define GROVE_G3 4
#define GROVE_G4 6
#define GROVE_G5 8
#define GROVE_G6 10
#define GROVE_G7 12


gpio DTH_init(int pin, gpio DTH){
	DTH = gpio_open(pin);
	gpio_set_direction(DTH, GPIO_IN);
	gpio_write(DTH, 1);
	return DTH;
}

float DTH_readtemperature(gpio DTH, uint8_t* data){
	float f;
	
	if(read_DTH(DTH, data)){
		f = data[2];
		return f;
	}
	return 0;
}

float C2F(float c){
	return c * 9 / 5 + 32;
}

float DTH_readhumidity(gpio DTH, uint8_t* data){
	float f;
	
	if(read_DTH(DTH, data)){
		f = data[0];
		return f;
	}
	return 0;
}

int read_DTH(gpio DTH, uint8_t* data){
	uint8_t laststate = 0;
	uint8_t counter = 0;
	int j = 1, i;
	
	gpio_write(DTH, 1);
	sleep(2);

	data[0] = data[1] = data[2] = data[3] = data[4] = 0;

	gpio_set_direction(DTH, GPIO_OUT);
	gpio_write(DTH, 0);
	usleep(20000);
	gpio_write(DTH, 1);
	usleep(40);
	gpio_set_direction(DTH, GPIO_IN);

	for (i=0; i< MAXTIMINGS; i++) {
	   counter = 0;
	   while (gpio_read(DTH) == laststate) {
	     counter++;
	     usleep(1);
	     if (counter == 255) {
	       break;
	     }
	   }
	   laststate = gpio_read(DTH);

	   if (counter == 255) break;

	   // ignore first 3 transitions
	   if ((i >= 5) && (laststate == 0)) {
	     // shove each bit into the storage bytes
	     data[j/8] <<= 1;
	     if (counter > 12)
	       data[j/8] |= 1;
	     j++;
	   }

	 }
	//data[0] = data[1] = data[2] = data[3] = data[4] = 1;
	//return 1;


  
  if ((j >= 40) && (data[4] == ((data[0] + data[1] + data[2] + data[3]) & 0xFF)) ) {
    return 1;
  }
  

  return 0;
  
}
