#include "DTH0.h"

int pin;
uint8_t data[6];
int firstread = 1;
gpio DTH;


void DTH_init(int pin){
	DTH = gpio_open(pin);
	gpio_set_direction(DTH, GPIO_IN);
	gpio_write(DTH, 1);
}

float DTH_readtemperature(gpio DTH, uint8_t* data){
	float f;
	
	if(read(DTH, data)){
		f = data[2];
		return f;
	}
}

float C2F(float c){
	return c * 9 / 5 + 32;
}

float DTH_readhumidity(gpio DTH, uint8_t* data){
	float f;
	
	if(read(DTH, data)){
		f = data[0];
		return f;
	}
}

int read(gpio DTH, uint8_t* data){
	uint8_t laststate = 0;
	uint8_t counter = 0;
	int j = 1, i;

	sleep(2);
	
	gpio_write(DTH, 1);
	sleep(2);

	data[0] = data[1] = data[2] = data[3] = data[4] = 0;

	gpio_set_direction(DTH, GPIO_OUT);
	gpio_write(DTH, 0);
	usleep(20000);
	gpio_write(DTH, 1);
	usleep(40);
	gpio_set_direction(DTH, GPIO_IN);

	for (i=0; i< MAXTIMINGS; i++) {
	   counter = 0;
	   while (gpio_read(DTH) == laststate) {
	     counter++;
	     usleep(1);
	     if (counter == 255) {
	       break;
	     }
	   }
	   laststate = gpio_read(DTH);

	   if (counter == 255) break;

	   // ignore first 3 transitions
	   if ((i >= 5) && (laststate == 0)) {
	     // shove each bit into the storage bytes
	     data[j/8] <<= 1;
	     if (counter > 15)
	       data[j/8] |= 1;
	     j++;
	   }

	 }
	//data[0] = data[1] = data[2] = data[3] = data[4] = 1;
	//return 1;


  
  if ((j >= 40) && (data[4] == ((data[0] + data[1] + data[2] + data[3]) & 0xFF)) ) {
    return 1;
  }
  

  return 0;
  
}


int main(){
	float temp,humi;

	DTH_init(GROVE_G2);

	while(1){
		temp = DTH_readtemperature(DTH, data);
		humi = DTH_readhumidity(DTH, data);
	}
	return 1;
}
